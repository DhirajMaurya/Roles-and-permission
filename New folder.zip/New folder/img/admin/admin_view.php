 <style>
    .errorType {
        border-color: red !important;
    }
        .loader_fs .fashion_load_body {
        /*background: none repeat scroll 0 0 rgba(51, 51, 51, 0.3);*/
        color: #333333;
        left: 52%;
        padding: 7px;
        position: fixed;
        top: 23%;
        margin-left: -87px;
        z-index: 100001;
    }
    
    .loader_fs .larger .load_msg {
        background: url(<?php echo(base_url());?>imagesbook/loading/loader10.gif) no-repeat scroll 6% 50% transparent;
        /*    background-size: 150px 200px;*/
        background-size: 200px 200px;
        font-size: 20px;
        padding: 300px 178px 0px 51px;
        /*padding: 100px 70px 15px 50px;*/
    }
    
    .fashion_order_load {
        /*background: url(<?php echo(base_url());?>imagesbook/loading/loader10.gif) repeat scroll 0 0 transparent !important;*/
        opacity: 0.5;
        z-index: 100000;
        width: 100%;
        height: 100%;
        position: fixed;
        top: 0;
        background-color: #111 !important;
    }
    
    .loader1 {
        position: absolute;
        left: 50%;
        top: 55%;
        z-index: 1;
        width: 150px;
        height: 150px;
        margin: -75px 0 0 -75px;
        border: 16px solid #f3f3f3;
        border-radius: 50%;
        border-top: 16px solid #2DCB74;
        width: 120px;
        height: 120px;
        -webkit-animation: spin 2s linear infinite;
        animation: spin 2s linear infinite;
    }
</style>
 <!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <div class="callout hide" id="message-box">
        <h4>I am an info callout!</h4>
        <font></font>
      </div>
      <?php
      $message=$this->session->flashdata('message');
      if($message!="")
      {
      ?>
      <div class="alert alert-success alert-dismissible" id="alert_message">
        <button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>
        <h4><i class="icon fa fa-check"></i> Alert!</h4>
        <?php echo $message; ?>
      </div>
      <?php
      } 
      $emessage=$this->session->flashdata('emessage');
      if($emessage!="")
      {
      ?>
      <div class="alert alert-danger alert-dismissible" id="emessage">
        <button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>
        <h4><i class="icon fa fa-ban"></i> Alert!</h4>
        <?php echo $emessage; ?>
      </div>
      <?php
      } 
      ?>
      
      <h1>
        Manage Admin
        <!-- <small>advanced tables</small> -->
        <!-- <a href="<?php echo site_url().'AdminController/admin_add/';?>" class="btn btn-md btn-primary pull-right"><i class="fa fa-fw fa-plus"></i> Add Admin</a> -->
        <button class="btn btn-md btn-primary pull-right" id="add_emp" onclick="addAndedit();"><i class="fa fa-fw fa-plus"></i> Add Admin</button>
      </h1>

      <!-- <ol class="breadcrumb">
        
        <li><a href="<?php echo site_url().'Dashboard';?>"><i class="fa fa-dashboard"></i> Home</a></li>
        <li><a href="#">Tables</a></li>
        <li class="active">Data tables</li>
      </ol> -->
    </section>
    <section class="content">
      <div class="row">
        <div class="col-xs-12">
          <div class="box box-primary">
            <div class="box-header form-inline">
              <div class="col-md-4">
              <select class="form-control select2" id="num_records" onchange="loadPagination(0,this.value)">
                <option value="5">5</option>
                <option value="10">10</option>
                <option value="25">25</option>
                <option value="50">50</option>
                <option value="100">100</option>
                <!-- <option value="-1">All</option> -->
              </select>
              </div>
              <div class="col-md-4" id="show_records">
              </div>
              <div class="col-md-4 pagination" style="margin: 0;">
              </div>
            </div>
            <!-- /.box-header -->
            <div class="box-body">
              <div class="table-responsive" id="postsList">
              <table class="table table-bordered table-striped">
                <thead class="bg-gray">
                <tr>
                  <th class="text-center">Id</th>
                  <th class="text-center">Username</th>
                  <th class="text-center">Name</th>
                  <th class="text-center">Gender</th>
                  <th class="text-center">Photo</th>
                  <th class="text-center">Email</th>
                  <th class="text-center">Mobile</th>
                  <th class="text-center">Role</th>
                  <!-- <th class="text-center">Permission</th> -->
                  <th class="text-center">Status</th>
                  <th class="text-center">Action</th>
                </tr>
                </thead>
                <tbody>
                
                </tbody>
              </table>
              <input type="hidden" value="0" class="pageno">
              <input type="hidden" value="" class="totalpage">
              
            <div id="loader-icon" style="left: 0;top: 40%;width:100%;height:100%;text-align:center;display:none;">
              <img src="<?php echo base_url().'imagesbook/loading/';?>loader11.gif" width="120px"/>
            </div>
            <div class='pagination col-md-4 pull-right' style="margin: 0;"></div>
            </div>
            <!-- /.box-body -->
          </div>
          <!-- /.box -->
        </div>
        <!-- /.col -->
      </div>
      <!-- /.row -->
    </section>
    <!-- /.content -->
  </div>

  <div class="modal fade" id="addAndedit">
    <div class="modal-dialog">
      <form id="submit" enctype="multipart/form-data">
      <div class="modal-content">
        <div class="modal-header">
          <button type="button" class="close" data-dismiss="modal" aria-label="Close">
            <span aria-hidden="true">&times;</span></button>
          <h4 class="modal-title">Add Employee</h4>
        </div>
        <div class="modal-body" style="padding: 10px 25px;">
          <div class="form-group">
            <label for="ufname">Full Name <span class="text-danger">*</span></label>
            <input type="text" class="form-control required" id="ufname" name="ufname" placeholder="Enter full name">
          </div>
          <div class="form-group">
            <label for="uname">Username <span class="text-danger">*</span></label>
            <input type="text" class="form-control required" id="uname" name="uname" placeholder="Enter Username."><!--  onchange="username_exit(this.value);" -->
          </div>
          <div class="form-group">
            <label>Select Gender <span class="text-danger">*</span></label>
            <div class="form-inline form-control ugender">
            <div class="radio" style="margin-right: 10%;">
              <label>
                <input type="radio" name="ugender" class="flat-red" id="gender1" value="1">
                Male
              </label>
            </div>
            <div class="radio" style="margin-right: 10%;">
              <label>
                <input type="radio" name="ugender" class="flat-red" id="gender2" value="2">
                Female
              </label>
            </div>
            </div>
          </div>
          <div class="form-group">
            <label for="urole">Role <span class="text-danger">*</span></label>
            <select class="form-control select2 required" name="urole" id="urole" style="width: 100%">
              <option value="">select</option>
              <?php foreach($role_data as $role_data){ ?>
                <option value="<?php echo($role_data->Roleid);?>"><?php echo($role_data->Rolename);?></option>
              <?php } ?>
            </select>
          </div>
          <div class="form-group">
            <label for="umobile">Mobile <span class="text-danger">*</span></label>
            <input type="text" class="form-control required" id="umobile" name="umobile" placeholder="Enter mobile ex.9876543210" onkeypress="return isNumberAllow(event);">
          </div>
          <div class="form-group">
            <label for="uemail">Email address <span class="text-danger">*</span></label>
            <input type="text" onchange="email_exit(this.value);" class="form-control required" id="uemail" name="uemail" placeholder="Enter email">
          </div>
          <div class="form-group">
            <label for="upass">Password <span class="text-danger">*</span></label>
            <input type="password" class="form-control required" id="upass" name="upass" placeholder="Enter password" autocomplete="off">
          </div>
          <div class="form-group">
            <label for="uphoto">Photo <span class="text-danger">*</span></label>
            <input id="uphoto" name="uphoto" type="file" data-msg-placeholder="Select {files} for upload...">
          </div>

          <div class="form-group ustatus">
            <label for="perm">Select Permission <span class="text-danger">*</span></label>
            <select class="form-control select2 required" multiple name="perm[]" id="perm" style="width: 100%">
              <?php foreach($perm_data as $perm_data){ ?>
              <option value="<?php echo($perm_data->Permid);?>"><?php echo($perm_data->Permdesc);?></option>
              <?php } ?>
            </select>
          </div>
          <div class="form-group row">
            <div class="col-sm-5">
            <label for="cap_value">Captcha Type <span class="text-danger">*</span></label>
            <input type="text" class="form-control required" id="cap_value" placeholder="Enter Captcha Code.">
            </div>
            <div class="col-md-7"  style="padding-top: 15px;">
            <span id="cap_image"><?php echo $cimage;?></span>
            <font class="h3" onclick="change_captcha()"><i class="fa fa-fw fa-refresh"></i></font>
            <input type="hidden" id="captcha_check" value="<?php echo $cvalues;?>">
            </div>
          </div>
          <div class="form-group ustatus">
            <label for="ustatus">Status <span class="text-danger">*</span></label>
            <select class="form-control select2 required" name="ustatus" id="ustatus" style="width: 100%">
              <option value="">select</option>
              <option value="1">Active</option>
              <option value="0">Deactive</option>
            </select>
          </div>
        </div>
        <div class="modal-footer">
          <button type="button" class="btn btn-default pull-left" data-dismiss="modal">Close</button>
          <button type="submit" class="btn btn-primary" id="saveEmployee">Save changes</button>
        </div>
      </div>
      </form>
      <!-- /.modal-content -->
    </div>
    <!-- /.modal-dialog -->
  </div>
  <!-- /.modal -->

<div class="modal fade" id="modal-default">
</div>
<div class="modal fade" id="myModal">
  <div class="modal-dialog modal-sm">
    <div class="modal-content text-center" style="padding: 7px;">
    </div>
  </div>
</div>
  <!-- /.content-wrapper -->
  <script type="text/javascript">

    $(function(){
      $("#uphoto").fileinput({
        showUpload: false,
        dropZoneEnabled: false,
        allowedFileExtensions: ["jpg", "png", "gif"]
        // maxFileCount: 10,
        // mainClass: "input-group-lg"
      });

      toastr.options = {
          "closeButton": true,
          "debug": false,
          "newestOnTop": true,
          "progressBar": false,
          "positionClass": "toast-top-right",
          "preventDuplicates": false,
          "onclick": null,
          "showDuration": "300",
          "hideDuration": "1000",
          "timeOut": "5000",
          "extendedTimeOut": "1000",
          "showEasing": "swing",
          "hideEasing": "linear",
          "showMethod": "slideDown",
          "hideMethod": "slideUp",
          "tapToDismiss": false
      }

    });

    //$('#add_emp').on('click',function(e){
    function addAndedit(id=''){
      if(id!='')
      {
        $.ajax({
                url: base_url+'AdminController/admin_edit/'+id,
                type: 'post',
                dataType: 'json',
                success:function(responseData)
                {
                  $("#uname").val(responseData.Uusername);
                  $("#ufname").val(responseData.Uname);
                  $("#gender1").is(":checked");
                  $("#gender2").is(":checked");
                  $("input[type=radio]:checked").val();
                  $("#uemail").val(responseData.Uemail);
                  $("#umobile").val(responseData.Umobile);
                  $("#upass").val(responseData.Upassword);
                  $("#uphoto").val(responseData.Uphoto);
                  $("#urole").val(responseData.Roleid);
                  $("#ustatus").select2(responseData.Ustatus);
                  //$("#perm").val(responseData.Umobile);
                }
        });

      }
      else
      {
        $('#uphoto').fileinput('reset');
        $('input[type="text"],input[type="file"],input[type="password"]').val('');
        $("#perm,#ustatus,#urole").val('').trigger('change');
      }
      $('.file-caption').removeClass('errorType');
      $('.ugender,input[type="text"],input[type="file"],input[type="password"]').removeClass('errorType');
      $('#urole,#perm,#ustatus').next('.select2-container').find('.select2-selection').removeClass('errorType');
      $('#gender1,#gender2').iCheck('uncheck');
      $('.loader_fs').show();
      setTimeout(function(){  $('#addAndedit').modal({show:true,backdrop:false}); $('.loader_fs').hide(); },2000);
      change_captcha();
    }

    $('#submit').submit(function(e){
      e.preventDefault(); 
      var uname = $("#uname").val();
      var ufname = $("#ufname").val();
      var gender1 = $("#gender1").is(":checked");
      var gender2 = $("#gender2").is(":checked");
      var gender = $("input[type=radio]:checked").val();
      var email = $("#uemail").val();
      var mobile = $("#umobile").val();
      var pass = $("#upass").val();
      var photo = $("#uphoto").val();
      var role = $("#urole").val();
      var status = $("#ustatus").val();
      var perm = $("#perm").val();

      var unp = /^[a-zA-Z0-9_]+$/;
      var np = /^[a-zA-Z ]+$/;
      var ep = /[a-zA-Z0-9]+\@gmail.com$/;
      var mp = /^[9876][0-9]{9}$/;

      var cap_value = $("#cap_value").val();
      var captcha_check = $("#captcha_check").val();
      

      var flag = true;
      $('.required').each(function()
      {
        var ctr_val=$(this).val();
        if(ctr_val == null || ctr_val == '' || ctr_val == undefined)
        {
          $(this).addClass('errorType');
          flag = false;
        }
        else
        {
          $(this).removeClass('errorType');
        }
      });
        
      $('select.required').each(function()
      {
        var ctr_val=$(this).val();
        if(ctr_val == null || ctr_val == '' || ctr_val == undefined)
        {
          $(this).next('.select2-container').find('.select2-selection').addClass('errorType');
          flag = false;
        }
        else
        {
          $(this).next('.select2-container').find('.select2-selection').removeClass('errorType');
        }
      });   

      if(photo=='')
      {
        $(".file-caption").addClass('errorType');
        flag = false;
      }
      else
      {
        $('.file-caption').removeClass('errorType');
      }
      if(!uname.match(unp)) 
      {
        $('#uname').addClass('errorType');
        flag = false;
      }
      else
      {
        $('#uname').removeClass('errorType');
      }
      if(!ufname.match(np)) 
      {
        $('#ufname').addClass('errorType');
        flag = false;
      }
      else
      {
        $('#ufname').removeClass('errorType');
      }
      if(gender1==false && gender2==false)
      {
        $(".ugender").addClass('errorType');
        flag = false;
      }
      else
      {
        $('.ugender').removeClass('errorType');
      }

      if(!email.match(ep)) 
      {
        $("#uemail").addClass('errorType');
        flag = false;
      }
      else
      {
        $('#uemail').removeClass('errorType');
      }
      if(!mobile.match(mp)) 
      {
        $("#umobile").addClass('errorType');
        flag = false;
      }
      else
      {
        $('#umobile').removeClass('errorType');
      }
      if(cap_value!=captcha_check) 
      {
        $("#cap_value").addClass('errorType');
        flag = false;
      }
      else
      {
        $('#cap_value').removeClass('errorType');
      }

      if(flag)
      {
        $('.loader_fs').show();

        $.ajax({
             url: base_url+'AdminController/admin_insert',
             type:"post",
             data:new FormData(this),
             processData:false,
             contentType:false,
             cache:false,
             async:false,
             success: function(data){
                setTimeout(function() { 
                  $('.loader_fs').hide();
                  var limit = $('#num_records').val();
                  loadPagination(0,limit);
                  $('#addAndedit').modal('hide');
                  if(data==2){
                    toastr["warning"]("Permission denied...");
                  }
                  else if(data==1){
                    toastr["success"]("Successfully submit record...");
                  }
                  else if(data==0)
                  {
                    toastr["error"]("Record not submit in Database...");
                  }
                  setTimeout(function() { $('#message-box').slideUp(1000); }, 5000);
                  //alert(data);
                }, 5000);
           }
         });
      }

      // return flag;
    });

    /*$('#submit').submit(function(e){
    e.preventDefault(); 
         $.ajax({
             url:'Your path',
             type:"post",
             data:new FormData(this),
             processData:false,
             contentType:false,
             cache:false,
             async:false,
              success: function(data){
                  alert(data);
           }
         });
    });*/


    function isNumberAllow(evt) {
        var charCode = (evt.which) ? evt.which : evt.keyCode;
        if (charCode > 31 && (charCode < 48 || charCode > 57)) {
            return false;
        }
        return true;
    }
    function view_photo(input) {
      if (input.files && input.files[0]) {
          var reader = new FileReader();
          
          reader.onload = function (e) {
              $("#rphoto").remove();
              $('#uphoto').after("<img src='"+e.target.result+"' id='rphoto' class='img img-thumbnail' style='height:150px'>");
              $("#error").remove();
          }
          
          reader.readAsDataURL(input.files[0]);
      }
    }

    function email_exit(email) {
      $("#error").remove();
      $.ajax({
              url:"<?php echo site_url().'AdminController/email_exit'?>",
              method:"post",
              data:{email},
              success:function(res)
              {
                if(res==1)
                {
                  $('#uemail').val('');
                  $("#uemail").focus();
                  $("#uemail").after("<small class='text-danger' id='error'>This Emailid is allready exit.</small>");
                }
                else{
                  $("#error").remove();
                }
              }
      });
    }

    function change_captcha()
    {
      $.ajax({
              url:"<?php echo site_url().'AdminController/refresh_captche';?>",
              success:function(res)
              {
                data = JSON.parse(res);
                $('#captcha_check').val(data.cvalues);
                $('#cap_image').html(data.cimage);
              }
      });
    }

  var limit = $('#num_records').val();
  $('.pagination').on('click','a',function(e){
    e.preventDefault(); 
    var limit = $('#num_records').val();
    var pageno = $(this).attr('data-ci-pagination-page');
    loadPagination(pageno,limit);
  });

  loadPagination(0,limit);

  function loadPagination(pageno,limit){
    // alert(limit);
    if(limit == -1)
    {
        $('#postsList tbody').empty('');
        $('.pagination').addClass('hide');
        $('#show_records').addClass('hide');
        $(window).scroll(function() {
          if($(window).scrollTop() == $(document).height() - $(window).height())
          {
            if($(".totalpage:last").val() != $(".pageno:last").val()) 
            {
              var pageno = parseInt($(".pageno:last").val()) + 1;
              $.ajax({
                url: "<?php echo site_url().'AdminController/admin_list/'?>"+pageno+'/'+limit,
                type: 'get',
                dataType: 'json',
                success: function(response){
                    $('.pagination').html(response.pagination);
                    $('#show_records').html(response.show_records);
                  
                    createTable(response.result,response.pageno);
                    
                    $('#postsList').append(response.page_tpage);
                }
              });
            }
          }
        });
    }
    else
    {
      $('#show_records').removeClass('hide');
      $('.pagination').removeClass('hide');
      $.ajax({
        url: "<?php echo site_url().'AdminController/admin_list/'?>"+pageno+'/'+limit,
        type: 'get',
        dataType: 'json',
        success: function(response){
          if(response.result=='')
          {
            loadPagination(response.pageno-1,limit);
          }
          else
          {
            $('.pagination').html(response.pagination);
            $('#show_records').html(response.show_records);
            createTable(response.result,response.pageno);
          }
        }
      });
    }
  }
  function createTable(result,sno){
   sno = Number(sno);
   if($('#num_records').val() != -1)
   {
      $('#postsList tbody').empty();
   }
   for(index in result){
      var id = result[index].Uid;
      var uname = result[index].Uusername;
      var name = result[index].Uname;
      var gender = result[index].Ugender;
      var photo = result[index].Uphoto;
      var email = result[index].Uemail;
      var mobile = result[index].Umobile;
      var role_name = result[index].Rolename;
      var status = result[index].Ustatus;
      //var content = result[index].slug;
      //content = content.substr(0, 60) + " ...";
      //var link = result[index].slug;
      sno+=1;
      if(gender==1)
      {
        g = 'Male';
      }
      else
      {
        g = 'Female';
      }
      if(status==1)
      {
        st = "<button title='Active' class='btn btn-success btn-sm' onclick='status("+ id +")'><span class='glyphicon glyphicon-ok-circle' style='font-size: 20px'></span></button>";
      }
      else
      {
        st = "<button title='Deactive' class='btn btn-danger btn-sm' onclick='status("+ id +")'><span class='glyphicon glyphicon-remove-circle' style='font-size: 20px'></span></button>";
      }

      var tr = "<tr>";
      tr += "<td class='text-center'>"+ id +"</td>";
      tr += "<td>"+ uname +"</td>";
      tr += "<td>"+ name +"</td>";
      tr += "<td>"+ g +"</td>";
      var n = '"'+name+'"';
      tr += "<td class='text-center'><img src='<?php echo site_url();?>imagesbook/admin_photo/"+ photo +"' width='60px' id='eimage_"+id+"' onclick='full_view("+ id +","+ n +")'></td>";
      
      tr += "<td>"+ email +"</td>";
      tr += "<td>"+ mobile +"</td>";
      tr += "<td>"+ role_name +"</td>";
      tr += "<td id='status_"+ id +"' class='text-center'>"+ st +"</td>";
      tr += "<td class='text-center'>"+
                "<a onclick='addAndedit("+ id +")' title='Edit'><i class='fa fa-fw fa-edit' style='font-size: 20px'></i></a> |"+ 
                "<a title='Delete' onclick='delete_record("+ id +")'><i class='fa fa-fw fa-trash' style='font-size: 20px;cursor: pointer;'></i></a> |"+ 
                "<a title='Delails' onclick='admin_details("+ id +")'><i class='fa fa-info-circle' style='font-size: 20px;cursor: pointer;'></i></a>"+
            "</td>";
      tr += "</tr>";
      $('#postsList tbody').append(tr);

    }
  }

  //"<a href='<?php //echo site_url().'AdminController/admin_edit/';?>"+ id +"' title='Edit'><i class='fa fa-fw fa-edit' style='font-size: 20px'></i></a> |"


    function full_view(id,name)
    {
      var data = $("#eimage_"+id).attr('src');
      $('#myModal').modal('show') 
      $('#myModal .modal-content').html("<img src='"+data+"' width='100%'' style='border:solid 5px #fff;'>"+"<span class='h3'>"+name+"</span>");
    }
    function status(id)
    {
      if(confirm('Do you want to change the status of record.'))
      {
        $.ajax({
                  url:"<?php echo site_url().'AdminController/admin_status/' ?>"+id,
                  success:function(res)
                  {
                    $("#status_"+id).html(res);
                  }
        });
      }
    }
    function delete_record(id)
    {

      var limit = $('#num_records').val();
      var pageno = $('.curlink span:last').text();
      if(confirm('Do you want to delete the record.'))
      {
        $.ajax({
                url:"<?php echo site_url().'AdminController/admin_delete/';?>"+id,
                method: "get",
                dataType: 'json',
                success:function(res)
                {
                  if(res.status == 1)
                  {
                    loadPagination(pageno,limit);
                  }
                  else
                  {
                    window.location.reload();
                  }
                }
        });
      }
    }
    function admin_details(id)
    {
      $('.loader_fs').show();
      $.ajax({
                url:"<?php echo site_url().'AdminController/admin_details/'?>"+id,
                success:function(res){
                  setTimeout(function() { 
                    $('.loader_fs').hide(); 
                    $("#modal-default").modal('show');
                    $("#modal-default").html(res);
                  },2000);
                }
      });
    }
    function num_records(records)
    {

      var url = window.location.href;
   
      if (url.search("ename") != -1) 
      {
        var ename = GetParameterValues('ename');  
        var egender = GetParameterValues('egender');  
        var edesignation = GetParameterValues('edesignation');  
        var estatus = GetParameterValues('estatus');  
        var equalification = GetParameterValues('equalification');  
        var eexperience = GetParameterValues('eexperience');  
        function GetParameterValues(param) {  
            var url = window.location.href.slice(window.location.href.indexOf('?') + 1).split('&');  
            for (var i = 0; i < url.length; i++) {  
                var urlparam = url[i].split('=');  
                if (urlparam[0] == param) {  
                    return urlparam[1];  
                }  
            }  
      } 
      var new_url = "<?php echo site_url().'AdminController/emp_view?show_records=';?>"+records+'&ename='+ename+'&egender='+egender+'&edesignation='+edesignation+'&estatus='+estatus+'&equalification='+equalification+'&eexperience='+eexperience;
      window.location.href = new_url;
      }
      else
      {
        var new_url = "<?php echo site_url().'AdminController/emp_view?show_records='; ?>"+records;
        window.location.href = new_url;
      }
    }

    
  </script>

  <div class="loader_fs global-loader" style="display: none;">
    <div class="fashion_load_body larger">
      <div class="load_msg">
      </div>
    </div>
    <div class="fashion_order_load">
    </div>
  </div>