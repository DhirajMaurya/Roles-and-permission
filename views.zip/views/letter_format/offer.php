<!DOCTYPE html>
<html>
<head>
	
</head>
<body>
	<center>	
		<h1 style="text-align: center;">Offer Letter</h1>
		<img src="<?php echo base_url();?>imagesbook/logo/header-logo.png" alt="DNK Technoliges">
		<hr/>
	</center>
	<table style="width:95%">
			<tr>
				<td align="right"> 
				<font face="Times" size="4" color="Black">Date : <?php  echo date("d/m/Y")?></font>	
				</td>
			</tr>
		</table>
		
		<table>
			<tr>
				<td>
					<font face="Times" size="5" color="Black">Cubber Technoliges Pvt. Ltd.</font>
				</td>
			</tr>	
			<tr>
				<td>
					<font face="Times" size="4" color="Black">305,Sunshine Complex,</font>
				</td>
			</tr>
			<tr>
				<td>
					<font face="Times" size="4" color="Black">Opp. CNG Pump, Nr. Sudama Chowk,</font>
				</td>
			</tr>		
			<tr>
				<td>
					<font face="Times" size="4" color="Black">Mota Varachha, Surat-394101</font>
				</td>
			</tr>
			<tr><td></td></tr>
			<tr><td></td></tr>
			<tr><td></td></tr>
			<tr><td></td></tr>
			<tr><td></td></tr>
			<tr><td></td></tr>
			
			<tr>
				<td>
					<font face="Times" size="4" color="Black">Dear <?php //echo "$name";?>,</font>
				</td>
			</tr>
			<tr>
				<td><font face="Times" size="4" color="Black">
					&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;We are pleased to offer placement with concern part of D & K Group of Companies named "Cubber Technoliges Pvt. Ltd." for the post of "<?php// echo "$post"; ?>" beginning on <?php //echo "$doj";?>. Tranning period is 3 months, on the basis of your performance in tranning you are pramotted  for perment employment.
				</font></td>
			</tr>

			<tr><td></td></tr>
			<tr><td></td></tr>
			<tr><td></td></tr>
			<tr><td></td></tr>
			<tr>
				<td>
					<font face="Times" size="4" color="Black">You are expected to be here by 9:30 am on the joining date.</font>  
				</td>
			</tr>
			<tr>
				<td>
					<font face="Times" size="4" color="Black">We are happy having you in our team.</font>  
				</td>
			</tr>
			<tr><td></td></tr>
			<tr><td></td></tr>
			<tr><td></td></tr>
			<tr><td></td></tr>	
			
			<tr>
				<td>
					<font face="Times" size="4" color="Black">Regards,</font>
				</td>
			</tr>
			<tr>
				<td>
					<font face="Times" size="4" color="Black">Cubber Technoliges Pvt. Ltd.</font>
				</td>
			</tr>
			<tr><td></td></tr>
			<tr><td></td></tr>
			<tr><td></td></tr>
			<tr><td></td></tr>	
			<tr><td></td></tr>
			<tr><td></td></tr>
			<tr><td></td></tr>
			<tr><td></td></tr>	
			<tr><td></td></tr>
			<tr><td></td></tr>
			<tr><td></td></tr>
			<tr><td></td></tr>	
			<tr><td></td></tr>
			<tr><td></td></tr>
			<tr><td></td></tr>
			<tr><td></td></tr>	
			<tr><td></td></tr>	
			<tr>
				<td><font face="Times" size="4" color="Black">Ansari Tosif</font></td>
			</tr>
			<tr>
				<td>
					<font face="Times" size="4" color="Black">Sr. HR Associate</font>
				</td>
			</tr>
		</table>
		<hr/>
		<table style="width:95%">
			<tr>
				<th align="left">
					<font face="Times" size="4" color=#ff9900>Head Office :</font>
				</th>
				<th align="left">
					<font face="Times" size="4" color=#ff9900>Branch Office :</font>
				</th>
			</tr>
			<tr>
				<td>
					<font face="Times" size="3" color=#ff9900>305,Sunshine Complex, Nr. Sudama Chowk,</font>
				</td>
				<td>
					<font face="Times" size="3" color=#ff9900>305,Sunshine Complex, Nr. Sudama Chowk,</font>
				</td>
			</tr>
			<tr>
				<td>
					<font face="Times" size="3" color=#ff9900>Opp. CNG Pump, Mota Varachha, Surat-394101</font>
				</td>
				<td>
					<font face="Times" size="3" color=#ff9900>Opp. CNG Pump, Mota Varachha, Surat-394101</font>
				</td>
			</tr>
			<tr>
				<td>
					<font face="Times" size="3" color=#ff9900>Tel. : +9190333 30404</font>
				</td>
				<td>
					<font face="Times" size="3" color=#ff9900>Tel. : +9190333 30404</font>
				</td>
			</tr>
			<tr>
				<td>
					<font face="Times" size="3" color=#ff9900>Email: info@dnktechnologies.com</font>
				</td>
				<td>
					<font face="Times" size="3" color=#ff9900>Email: info@dnktechnologies.com</font>
				</td>
			</tr>
		</table>
		<center><font face="Times" size="3" color=#ff9900>www.dnktechnologies.com</font></center>
</div>	
</body>

</html>